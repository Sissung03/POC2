# Protocole de calibration HIBOU-OS --- Cycle 1 (v1.1 FINAL)

Tranché le 30 septembre 2026 --- finalisé par Cooper sur délégation
experte de Denard (décision : trancher sans attendre Roqia).

v1.1 : mise en cohérence avec le treillis 5+2 implémenté dans le PoC le
30 sept. 2026 (code : decide_action 7 sorties ; statut de cycle de vie
verdict_status renommé OBSERVE → SUIVI pour lever la collision de
vocabulaire).

Statut : FINAL. Remplace le brouillon docs/protocole_calibration.md du
PoC.

Références architecture : définition officielle v2, treillis canonique
5+2, spec capability engine v1.0
(\~/workspace/your_files/hibou_capability_engine_spec.md).

------------------------------------------------------------------------------------------------------------------------

## 0. Principes constitutionnels (non négociables, jamais calibrés)

Ces invariants ne sont pas des paramètres : ils ne se « règlent » pas.

-   Hard gates évalués avant toute agrégation (non-compensation
    stricte).

-   Invariant C ≤ Cap(State) --- plafonnement par état.

-   T = f(R, I, Rev) indépendant de C (∂T/∂C = 0, vérifié par test).

-   Palier maximal (T ≥ 0,9) : sorties admissibles = {STOP, ESCALATE}
    uniquement.

-   UNKNOWN ou CONFLICTED → STOP, quel que soit T (tranché 28 sept.
    2026).

-   SEEK = directive d\'évaluation (collecter plus d\'évidence,
    ré-évaluer), pas un niveau d\'autonomie.

-   /outcome n\'ajuste jamais T, les gates ou les poids en direct : il
    alimente SCI-MEM pour un cycle de recalibration gouverné.

Tout le reste (poids, seuils, plafonds, bornes de T, seuils C) est
calibrable.

------------------------------------------------------------------------------------------------------------------------

## 1. Objectif du cycle 1

Passer des « ancrages initiaux » à des paramètres empiriquement fondés
sur des décisions réelles tracées via SCI-MEM. Objectif modeste et
explicite : réduire l\'arbitraire et mesurer la cohérence --- pas
atteindre une vérité absolue.

Périmètre de calibration du cycle 1 : le mécanisme discret. Le PoC
implémente le treillis 5+2 complet (OBSERVE / RECOMMEND / VERIFY /
DEGRADED / ACT + ESCALATE / STOP latéraux) depuis la mise à jour du 30
sept. 2026. Seul le governor continu (principe PPS : hystérésis,
slew-rate, régulation intra-niveau) relève de la phase 2 et sera calibré
sur des données continues du 24/7. Le cycle 1 ne bloque pas sur lui ---
il documente explicitement cette couverture partielle.

------------------------------------------------------------------------------------------------------------------------

## 2. Domaine de collecte (tranché)

AWA3P-DIPOS, adaptateur n°1. La plateforme est opérationnelle, les
données peuvent circuler maintenant. Le cycle 1 calibre les paramètres
transversaux du kernel (seuils, gates, bornes T) --- par construction
indépendants du domaine. L\'adaptateur trading (n°2) fera l\'objet
d\'une calibration partielle dédiée sur sa propre distribution (§8),
sans attendre.

Cas pilotes (tranchés 30 sept. 2026, à valider sur les flux réels) : 2
types de décisions couvrant tout le spectre de T --- requis pour
l\'analyse de sensibilité aux bornes (§4.6) :

-   Type 1 --- Qualification des menaces (stage Threat) : un signal
    est-il une menace réelle ? Volume élevé, enjeu modéré, outcome =
    confirmation/infirmation ultérieure. Calibre les bandes basses de T
    et les sorties ACT / VERIFY / RECOMMEND.

-   Type 2 --- Sélection de la réponse (stage Response) : menace
    qualifiée → immuniser / bloquer / surveiller / escalader. Volume
    modéré, enjeu élevé, outcome = résolution de l\'incident. Calibre
    les bandes hautes de T, ESCALATE / STOP.

-   R/I/Rev naturellement renseignables aux deux niveaux (une menace a
    un impact ; une réponse a une réversibilité).

-   ⚠️ Hypothèse : Denard confirme que ces deux types existent dans les
    flux opérationnels avec le volume requis (\~150 décisions au total),
    ou substitue les vrais noms des flux.

Vague 0 --- shakedown méthodologique (50 décisions) : avant la collecte
complète, 50 premières décisions pour valider l\'instrumentation
(formulaire R/I/Rev, aveugle au verdict, canaux
/outcome-/review-/arbitration) et mesurer l\'accord inter-opérateurs. Si
l\'accord \< 75 % ou si l\'instrumentation fuit, on corrige la méthode
--- pas les données. Puis collecte complète jusqu\'à \~150.

------------------------------------------------------------------------------------------------------------------------

## 3. Collecte --- tracer des décisions réelles (SCI-MEM)

-   Instrumentation : toute décision passe par /submit_decision_context
    avec R, I, Rev renseignés par l\'opérateur au moment de la décision
    (jamais reconstruits après coup), en aveugle du verdict (avant de
    voir la sortie du système --- anti-gaming).

-   Méthode R/I/Rev (tranchée) --- échelles 0--1 ancrées, pas
    d\'intuition libre :

\- R (risque) : 0 = négligeable · 0,25 = faible (désagrément mineur) ·
0,5 = modéré (coût significatif, absorbable) · 0,75 = élevé (dommage
sérieux) · 1,0 = critique.

\- I (impact) : 0 = aucun · 0,25 = individuel/limité · 0,5 =
équipe/processus · 0,75 = organisation/client · 1,0 = systémique.

\- Rev (réversibilité) : 0 = irréversible · 0,25 = réversible à coût
élevé · 0,5 = coût modéré · 0,75 = facilement réversible · 1,0 =
trivialement réversible. Polarité : Rev élevé → prudence requise
moindre.

\- Homogénéité : formulaire structuré à 3 curseurs ancrés, rempli avant
le verdict. Sur \~20 décisions communes, mesure d\'accord
inter-opérateurs (cible : ≥ 75 %). En cas de désaccord systématique, les
ancres sont reformulées --- pas les données.

-   Vérité terrain (3 canaux) : chaque décision reçoit un outcome via
    /outcome (horizon IMMEDIAT / COURT_DELAI / LONG_DELAI) ; un
    échantillon stratifié reçoit des reviews via /review ; chaque
    décision non-ACT reçoit sa résolution via /arbitration. Voir
    docs/canaux_verite_terrain.md.

-   Cible : \~150 décisions, stratification visée sur les 5 niveaux du
    treillis (idéalement ≥ 15 par niveau : OBSERVE, RECOMMEND, VERIFY,
    DEGRADED, ACT). ESCALATE/STOP sont rares par construction --- on les
    compte et on documente, on ne les force pas. Si un niveau est
    introuvable en réel, biais de couverture documenté (pas de
    synthétique de remplissage).

-   Gel du dataset : export JSON immuable et versionné
    (dataset_calib_v1.json, hash noté au journal d\'audit). On ne
    calibre jamais sur un jeu qu\'on modifie en cours de route.

------------------------------------------------------------------------------------------------------------------------

## 4. Métriques --- calculées hors ligne, jamais en prod

Sur le dataset gelé :

1.  Distributions : sorties, C, C_raw vs C (effet du plafonnement), T.
    Étendre le dashboard Streamlit avec T si besoin.

2.  Pouvoir prédictif de C : taux de SUCCESS par bande de C et par
    sortie. Si les C élevés ne réussissent pas plus que les C faibles,
    poids ou seuils à revoir.

3.  Revue experte --- le cœur du cycle 1 : \~30 décisions en échantillon
    stratifié, revues par Denard (+ Roqia si disponible), en aveugle du
    système :

\- le State était-il juste ?

\- la sortie (ACT/VERIFY/RECOMMEND/ESCALATE/STOP) était-elle la bonne ?

\- R, I, Rev étaient-ils bien évalués ?

→ matrice de confusion « expert vs système », avec verbatims.

4.  Faux positifs/négatifs des gates : ex. UNKNOWN alors que la donnée
    existait (normalisateur trop strict), ou STABLE alors qu\'un expert
    voit une lacune critique (gate trop laxiste).

5.  Question CONFLICTED vs UNKNOWN → réponse empirique : parmi les STOP
    déclenchés par CONFLICTED, quel % les experts auraient-ils escaladé
    plutôt que stoppé ? Si ce % est élevé et stable, la distinction fine
    CONFLICTED→ESCALATE / UNKNOWN→STOP sera réévaluée au cycle 2.
    (Tranche la question ouverte n°2 du briefing par la mesure, pas par
    décret.)

6.  Sensibilité aux seuils : décisions à T proche des bornes (0,4 / 0,7
    / 0,9) --- combien basculeraient si la borne bougeait de ±0,05 ? Si
    beaucoup, la borne est fragile : justifiée ou déplacée.

------------------------------------------------------------------------------------------------------------------------

## 5. Ajustements --- ordre et discipline

Ordre (amont → aval) : (1) THRESHOLDS et STATE_CAP ; (2) ALPHA_WEIGHTS
(rapports relatifs) ; (3) T_WEIGHTS, T_BINS, seuils d\'action --- les
plus sensibles, en dernier.

Règles :

-   Un cycle = un jeu de paramètres proposé (diff versionné config v1.0
    → v1.1).

-   Chaque changement justifié par une mesure chiffrée (ex. : « relever
    fragile de 0,50 à 0,55 réduit les FRAGILE faux positifs de 22 % à 9
    % sur l\'échantillon expert »).

-   Interdit : ajuster sur le dataset puis re-mesurer le succès sur ce
    même dataset sans jeu de confirmation. Le jeu de confirmation =
    nouvelles décisions tracées \*après\* l\'ajustement (cycle 2).

-   Les rapports relatifs entre poids ne changent que sur justification
    experte, pas sur bruit statistique (n=150 reste petit).

-   Chaque finding tagué transversal (tient indépendamment du domaine
    --- ex. bornes T, hard gates) vs domaine (dépend de la distribution
    DIPOS --- ex. poids ALPHA). Un paramètre tagué \*domaine\* ne se
    généralise pas sans revalidation (notamment vers le trading).

------------------------------------------------------------------------------------------------------------------------

## 6. Gouvernance du changement

-   Paramètres versionnés dans config.py, journal d\'audit : qui / quand
    / quoi / pourquoi / sur quelles données (hash du dataset).

-   Validation : Denard signe le diff. Roqia relit quand disponible (non
    bloquant).

-   Déploiement : redémarrage versionné, jamais d\'ajustement temps
    réel. Version précédente conservée avec rejeu possible sur le
    dataset gelé (rollback + audit).

-   Toute modification ultérieure repart du §4 sur de nouvelles données.

------------------------------------------------------------------------------------------------------------------------

## 7. Critères de sortie du cycle 1

-   \[ \] Les 5 niveaux du treillis observés au moins une fois en réel
    (ou biais de couverture documenté) ; le governor continu
    explicitement reporté en phase 2 ;

-   \[ \] accord expert-système sur l\'échantillon revu ≥ 80 % ;

-   \[ \] analyse de sensibilité (§4.6) sans falaise (pas de borne où
    ±0,05 fait basculer \> 15 % des décisions) ;

-   \[ \] accord inter-opérateurs R/I/Rev ≥ 75 % sur le sous-échantillon
    commun ;

-   \[ \] question CONFLICTED vs UNKNOWN mesurée (§4.5) ;

-   \[ \] rapport de calibration (1 page : données, changements,
    justifications, limites connues) signé par Denard.

------------------------------------------------------------------------------------------------------------------------

## 8. Après le cycle 1

-   Cycle 2 : nouvelles décisions réelles → jeu de confirmation. On
    mesure, on ne réajuste pas sur le cycle 1.

-   Calibration partielle trading : quand l\'adaptateur n°2 existe et
    qu\'un pilote est signé --- nouvelle distribution = nouvelle
    collecte ciblée ; les paramètres tagués \*transversal\* sont
    réutilisés, les \*domaine\* sont recalibrés.

-   Phase 2 governor : hystérésis, R_max, régulation continue
    intra-niveau --- calibrés sur données continues du 24/7, pas sur le
    cycle 1. (Le plancher de confiance OBSERVE et le plafonnement
    DEGRADED à T élevé, eux, sont des paramètres discrets couverts par
    le cycle 1.)

-   Seulement après un cycle 2 stable : élargissement à un nouveau cas
    d\'usage.

------------------------------------------------------------------------------------------------------------------------

## 9. Transversalité (rappel stratégique)

Le mapping DIPOS → CSV est l\'adaptateur n°1, pas la définition. Le
contrat transversal, c\'est les 8 dimensions + R/I/Rev + le treillis
5+2. Chaque nouveau domaine fournit son propre adaptateur vers ce
contrat ; aucun concept métier d\'un pilote ne doit fuir dans le cœur.
Le cœur (compute_confidence, compute_T, decide_action) reste agnostique
: uniquement des CSV 0--4 et des R/I/Rev 0--1. Tout test qui importerait
un vocabulaire métier est un signal d\'alarme.
