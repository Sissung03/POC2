# Dimensions du CSV — définitions

> **Statut : VALIDÉ par Denard le 28 sept. 2026.** Ces définitions,
> reconstruites à partir du code (`compute_confidence.py`,
> `normalize_spec.yaml`, `generate_dataset.py`, `decisions_sample.json`),
> sont désormais le contrat sémantique officiel du CSV.

Le CSV (Confidence State Vector) compte 8 dimensions normalisées dans [0, 1].
Zéro = absence/défaillance totale sur la dimension. Les poids relatifs
(rapports 3:2 entre les six premières et M/G) sont des ancrages initiaux
non calibrés — voir `app/config.py`.

| Dim | Nom proposé | Ce qu'elle mesure | Preuve dans le code |
|-----|-------------|-------------------|---------------------|
| **Q** | Qualité des données sources | Fiabilité et exploitabilité des données d'entrée : authenticité/provenance (`signed`), score de confiance, fraîcheur (décroissance exponentielle ~0,1/heure), complétude (`present/required`), rapport signal/bruit | Formule dédiée dans `normalize_value` : `0.25·p + 0.25·fraîcheur + 0.25·complétude + 0.25·snr` |
| **D** | Divergence / contradiction | Niveau de contradiction entre sources : 0 = contradiction bloquante → état CONFLICTED | `contradiction_threshold: 0.7` dans le yaml ; gate `D → CONFLICTED` ; exemple d-0003 `contradiction_sources` avec D=0 |
| **K** | Knowledge (validité des connaissances) | Fraîcheur et validité des connaissances mobilisées pour décider | `obsolescence_lambda` (~0,04/heure) dans le yaml |
| **X** | Contexte (adéquation) | Adéquation et persistance du contexte décisionnel | `context_decay` dans le yaml |
| **E** | Evidence (corroboration) | Redondance corroborante : la conclusion est-elle portée par plusieurs sources indépendantes ? | `redundancy_required: 2` dans le yaml ; FRAGILE quand E bas dans le générateur |
| **S** | Stabilité du signal | Stabilité / faible variance du signal ou du raisonnement | `var_max: 1.0` dans le yaml ; FRAGILE quand S bas dans le générateur |
| **M** | Mémoire (historique décisionnel) | Poids de l'historique : décisions passées, anomalies signalées | `anomaly_flag_weight` dans le yaml ; poids 0,10 |
| **G** | Gap Adequacy (couverture des lacunes) | Couverture des lacunes critiques : 0 = lacune critique non résolue → état UNKNOWN ; 1 = aucune lacune critique | Commentaire explicite dans `normalize_spec.yaml` ; gate `G → UNKNOWN` |

## Rôles dans les hard gates (après correctif)

- `G ≤ ε` → **UNKNOWN** (aucune base) ; `D ≤ ε` → **CONFLICTED** (base contradictoire)
- `Q, K, X, G < 0,25` → **DEGRADED** (fondamentaux faibles)
- `S, E, M < 0,50` → **FRAGILE**
- Tout ≥ 0,75 → **ROBUST**, sinon **STABLE**

## Contrat de normalisation (règle ajoutée avec le correctif)

Tout normalisateur continu **DOIT** émettre exactement `0.0` pour
"absent / non mesuré". Le gate utilise `≤ GATE_EPSILON` (1e-9) uniquement
comme protection contre le bruit flottant, pas comme seuil sémantique.
