## Addendum — 30 sept. 2026 : treillis canonique 5+2 implémenté

Tranché par Cooper sur délégation experte de Denard : `decide_action` produit désormais le treillis
5+2 — `OBSERVE < RECOMMEND < VERIFY < DEGRADED < ACT` + `ESCALATE`, `STOP` latéraux.
Sémantique discrète : plancher de confiance `C_OBSERVE_FLOOR = 0.3` (symbolique) → OBSERVE ;
à T élevé (0.7–0.9), ACT jamais accordé → DEGRADED au mieux ; palier maximal évalué avant le
plancher (ESCALATE prime). Le statut de cycle de vie `verdict_status` de `/outcome` est renommé
OBSERVE → SUIVI (levée de la collision de vocabulaire avec le niveau OBSERVE du treillis).
37 tests verts. La décision SEEK ci-dessous (28 sept.) reste valide : SEEK = directive, pas un niveau.

---
# Décisions à trancher (avant calibration)

## 1. SEEK — ✅ TRANCHÉ le 28 sept. 2026 (Cooper, sur délégation de Denard)

**Décision.** SEEK reste un **sous-état d'exécution de la métacognition**,
pas une sortie de h(T,C). L'automate de gouvernance est inchangé
(sorties : STOP / ESCALATE / VERIFY / RECOMMEND / ACT).

**Contrat d'exécution documenté (pour le futur Kernel) :**
- SEEK se déclenche (a) pendant l'exécution de VERIFY, quand la stratégie
  de vérification exige d'**acquérir de nouvelles données** (vs. confronter
  des sources existantes) ; (b) en phase de diagnostic, quand des entrées
  requises sont manquantes avant même le calcul de confiance.
- SEEK est **borné** (N tentatives, délai max — paramètres à calibrer).
- Épuisement des tentatives → STOP si le State est UNKNOWN/CONFLICTED
  (critère §2 : rien de fiable à transmettre), sinon ESCALATE avec le
  contexte partiel pour arbitrage humain.

L'alternative écartée (SEEK comme 6e sortie de h) complexifiait l'automate
et ses invariants testés sans bénéfice démontré à ce stade.

## 2. UNKNOWN/CONFLICTED à T non maximal — ✅ TRANCHÉ le 28 sept. 2026 (Cooper, sur délégation de Denard ; à revoir avec Roqia en calibration)

**Décision.** Le critère STOP-vs-ESCALATE validé le 26 sept. 2026 est
**étendu à toutes les bandes de T** : si le State est UNKNOWN ou
CONFLICTED → **STOP, quel que soit T**. Implémenté dans `decide_action`
(retour anticipé avant les bandes de T), testé
(`test_broken_confidence_forces_stop_at_any_t`).

**Justification.** Symétrie avec l'invariant d'indépendance : de même que
T ne dépend pas de C, ce critère ne dépend pas de T. Le rationnel
"demander un arbitrage humain sur du bruit n'a pas de sens" vaut à tout
niveau de risque, pas seulement au palier maximal.

**Note.** Le regroupement UNKNOWN/CONFLICTED → STOP reprend la validation
du 26 sept. sans la rouvrir. La distinction fine (CONFLICTED = deux
sources contradictoires = base transmissible à un humain ?) reste une
question ouverte pour la calibration avec Roqia.

**Impact mesuré :** d-0003 (`contradiction_sources`) et d-0004
(`donnee_manquante`) passent de VERIFY à STOP. d-0001 et d-0002 inchangés.

## 3. Sémantique du "quasi-zéro" continu (déjà partiellement traité)

**Constat.** Le correctif appliqué (`GATE_EPSILON = 1e-9`, G dans les
fondamentaux DEGRADED) protège du bruit flottant et du fail-open démontré
(G=0,0004 → STABLE). Reste une question de calibration : une source
continue qui score honnêtement G=0,05 — est-ce "absent" (UNKNOWN) ou
"faible" (DEGRADED) ? Le code actuel répond DEGRADED.

**Recommandation.** Garder le comportement actuel (seuil sémantique =
`fundamental_low` = 0,25 pour DEGRADED, epsilon uniquement anti-bruit) et
en faire un point de calibration empirique avec Roqia : mesurer la
distribution réelle des scores G sur les premières centaines de décisions
tracées avant d'ajuster.

## 4. Authentification (pré-déploiement, non bloquant pour le PoC)

Les endpoints n'ont aucune authentification — normal à ce stade. Avant
toute exposition : clé API via variable d'environnement (`HIBOU_API_KEY`,
désactivée si non définie pour ne pas casser le PoC local) + décorateur
sur les routes. ~20 lignes, à faire le jour où le service quitte localhost.
