# governance.py
# Confidence Governance Engine — version POC.
# T = f(R, I, Rev), indépendant de C (invariant dT/dC = 0).
# A = h(T, C) — brouillon de travail, voir Document Technique v0, Partie 5.
# Statut : hypothèse de travail, non calibré.

from .config import (
    T_WEIGHTS, T_BINS, C_ACT_THRESHOLD_LOW_T, C_ACT_THRESHOLD_MID_T,
    C_ACT_THRESHOLD_HIGH_T, C_OBSERVE_FLOOR, STOP_CONFIDENCE_STATES,
)


def compute_T(R, I, Rev):
    """Première forme concrète de T = f(R, I, Rev). Ne dépend jamais de C."""
    t = (
        T_WEIGHTS["R"] * R
        + T_WEIGHTS["I"] * I
        + T_WEIGHTS["REV_COMPLEMENT"] * (1 - Rev)
    )
    return min(1.0, max(0.0, t))


def decide_action(T, C, confidence_state=None):
    """A = h(T, C) — treillis canonique 5+2 (tranché le 30 sept. 2026).

    Échelle d'autonomie monotone :
        OBSERVE < RECOMMEND < VERIFY < DEGRADED < ACT
    Interventions latérales : ESCALATE (gel + transfert humain), STOP
    (blocage dur). SEEK n'est pas un niveau : c'est une directive
    (collecter de l'évidence puis réévaluer).

    Sémantique discrète (ancrages non calibrés) :
    - Hard gates UNKNOWN/CONFLICTED -> STOP, quel que soit T (30 sept. 2026).
    - Palier maximal (T >= 0.9), état connu -> ESCALATE : arbitrage humain
      sur une base réelle, même dégradée. Jamais d'autonomie au palier
      maximal. Le palier maximal est évalué AVANT le plancher OBSERVE :
      à enjeu maximal, l'arbitrage humain prime sur l'observation passive.
    - Sous le plancher de confiance -> OBSERVE : la base est trop mince
      pour agir comme pour vérifier quoi que ce soit de précis.
    - T élevé (0.7-0.9) : pleine autonomie (ACT) jamais accordée — au mieux
      DEGRADED (capacité réduite ; le governor continu la modulera en
      phase 2). C insuffisant -> RECOMMEND.
    - Bandes modérée et basse : inchangées (ACT si C suffit, sinon VERIFY).

    C influence toujours le comportement, sauf quand la pipeline de
    confiance elle-même a échoué (STOP).
    """
    if confidence_state in STOP_CONFIDENCE_STATES:
        return "STOP"

    if T >= T_BINS["maximal"]:
        return "ESCALATE"

    if C < C_OBSERVE_FLOOR:
        return "OBSERVE"

    if T >= T_BINS["eleve"]:
        return "DEGRADED" if C >= C_ACT_THRESHOLD_HIGH_T else "RECOMMEND"

    if T >= T_BINS["modere"]:
        return "ACT" if C >= C_ACT_THRESHOLD_MID_T else "VERIFY"

    return "ACT" if C >= C_ACT_THRESHOLD_LOW_T else "VERIFY"
