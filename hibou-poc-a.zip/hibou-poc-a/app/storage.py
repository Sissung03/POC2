# storage.py
# SCI-MEM minimal — trace chaque décision (DecisionRecord) et son
# éventuel résultat observé (Partie 7 du Document Technique v0 :
# feedback à 3 canaux, jamais de réapprentissage en temps réel).

import json
import os
import sqlite3
import uuid
from datetime import datetime

DB_PATH = os.environ.get("HIBOU_DB", "hibou_poc.db")


class DecisionStore:
    def __init__(self, db_path=None):
        self.conn = sqlite3.connect(db_path or DB_PATH, check_same_thread=False)
        self._init_schema()

    def _init_schema(self):
        c = self.conn.cursor()
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS decisions (
                id TEXT PRIMARY KEY,
                timestamp TEXT,
                context TEXT,
                confidence_report TEXT,
                R REAL, I REAL, Rev REAL, T REAL,
                action TEXT,
                verdict_status TEXT DEFAULT 'EN_ATTENTE',
                outcome TEXT,
                outcome_metrics TEXT,
                outcome_horizon TEXT,
                outcome_notes TEXT,
                outcome_timestamp TEXT
            )
            """
        )
        # Canal 2 — revue experte : jugement offline du *processus* de
        # décision (State et A corrects ?), indépendant du résultat observé.
        # Plusieurs experts peuvent revoir la même décision.
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS reviews (
                id TEXT PRIMARY KEY,
                decision_id TEXT NOT NULL,
                reviewer TEXT NOT NULL,
                timestamp TEXT,
                state_verdict TEXT NOT NULL,
                state_corrected TEXT,
                action_verdict TEXT NOT NULL,
                action_corrected TEXT,
                r_assessment TEXT,
                i_assessment TEXT,
                rev_assessment TEXT,
                notes TEXT
            )
            """
        )
        # Canal 3 — arbitrage humain : résolution enregistrée pour chaque
        # décision que HIBOU a escaladée ou arrêtée (ce que l'humain a
        # finalement décidé + son accord avec le cadrage de HIBOU).
        # Une seule résolution par décision (la dernière écrase).
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS arbitrations (
                decision_id TEXT PRIMARY KEY,
                resolver TEXT NOT NULL,
                timestamp TEXT,
                hibou_action TEXT NOT NULL,
                resolution TEXT NOT NULL,
                resolution_detail TEXT,
                agreement TEXT NOT NULL,
                latency_seconds REAL,
                notes TEXT
            )
            """
        )
        self.conn.commit()

    def save_decision(self, context, conf, R, I, Rev, T, action):
        decision_id = str(uuid.uuid4())
        ts = datetime.utcnow().isoformat() + "Z"
        c = self.conn.cursor()
        c.execute(
            "INSERT INTO decisions (id, timestamp, context, confidence_report, R, I, Rev, T, action, verdict_status) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'EN_ATTENTE')",
            (decision_id, ts, json.dumps(context), json.dumps(conf), R, I, Rev, T, action),
        )
        self.conn.commit()
        return decision_id

    def save_outcome(self, decision_id, outcome, metrics=None, horizon="IMMEDIAT", notes=None):
        """Relie un résultat observé à une décision tracée (canal de vérité
        terrain — voir Document Technique v0, Partie 7). N'ajuste jamais
        les poids/seuils en direct ; alimente seulement la traçabilité
        pour un cycle de recalibration gouverné ultérieur."""
        ts = datetime.utcnow().isoformat() + "Z"
        c = self.conn.cursor()
        c.execute(
            "UPDATE decisions SET verdict_status = 'SUIVI', outcome = ?, outcome_metrics = ?, "
            "outcome_horizon = ?, outcome_notes = ?, outcome_timestamp = ? WHERE id = ?",
            (outcome, json.dumps(metrics or {}), horizon, notes, ts, decision_id),
        )
        self.conn.commit()
        return c.rowcount > 0

    def save_review(self, decision_id, reviewer, state_verdict, state_corrected,
                    action_verdict, action_corrected, r_assessment=None,
                    i_assessment=None, rev_assessment=None, notes=None):
        """Canal 2 — revue experte. Retourne l'id de la revue, ou None si la
        décision n'existe pas. N'ajuste jamais les paramètres en direct."""
        if self._decision_exists(decision_id) is False:
            return None
        review_id = str(uuid.uuid4())
        ts = datetime.utcnow().isoformat() + "Z"
        c = self.conn.cursor()
        c.execute(
            "INSERT INTO reviews (id, decision_id, reviewer, timestamp, state_verdict, "
            "state_corrected, action_verdict, action_corrected, r_assessment, "
            "i_assessment, rev_assessment, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (review_id, decision_id, reviewer, ts, state_verdict, state_corrected,
             action_verdict, action_corrected, r_assessment, i_assessment,
             rev_assessment, notes),
        )
        self.conn.commit()
        return review_id

    def save_arbitration(self, decision_id, resolver, hibou_action, resolution,
                         resolution_detail, agreement, latency_seconds=None,
                         notes=None):
        """Canal 3 — arbitrage humain. Retourne False si la décision
        n'existe pas. N'ajuste jamais les paramètres en direct."""
        if self._decision_exists(decision_id) is False:
            return False
        ts = datetime.utcnow().isoformat() + "Z"
        c = self.conn.cursor()
        c.execute(
            "INSERT OR REPLACE INTO arbitrations (decision_id, resolver, timestamp, "
            "hibou_action, resolution, resolution_detail, agreement, latency_seconds, "
            "notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (decision_id, resolver, ts, hibou_action, resolution,
             resolution_detail, agreement, latency_seconds, notes),
        )
        self.conn.commit()
        return True

    def _decision_exists(self, decision_id):
        c = self.conn.cursor()
        c.execute("SELECT 1 FROM decisions WHERE id = ?", (decision_id,))
        return c.fetchone() is not None

    def get_reviews(self, decision_id):
        c = self.conn.cursor()
        c.execute(
            "SELECT id, reviewer, timestamp, state_verdict, state_corrected, "
            "action_verdict, action_corrected, r_assessment, i_assessment, "
            "rev_assessment, notes FROM reviews WHERE decision_id = ? "
            "ORDER BY timestamp",
            (decision_id,),
        )
        keys = ["id", "reviewer", "timestamp", "state_verdict", "state_corrected",
                "action_verdict", "action_corrected", "r_assessment",
                "i_assessment", "rev_assessment", "notes"]
        return [dict(zip(keys, row)) for row in c.fetchall()]

    def get_arbitration(self, decision_id):
        c = self.conn.cursor()
        c.execute(
            "SELECT resolver, timestamp, hibou_action, resolution, "
            "resolution_detail, agreement, latency_seconds, notes "
            "FROM arbitrations WHERE decision_id = ?",
            (decision_id,),
        )
        row = c.fetchone()
        if row is None:
            return None
        keys = ["resolver", "timestamp", "hibou_action", "resolution",
                "resolution_detail", "agreement", "latency_seconds", "notes"]
        return dict(zip(keys, row))

    def get_decision(self, decision_id):
        c = self.conn.cursor()
        c.execute(
            "SELECT id, timestamp, context, confidence_report, R, I, Rev, T, action, "
            "verdict_status, outcome, outcome_metrics, outcome_horizon, outcome_notes, outcome_timestamp "
            "FROM decisions WHERE id = ?",
            (decision_id,),
        )
        row = c.fetchone()
        if row is None:
            return None
        keys = ["id", "timestamp", "context", "confidence_report", "R", "I", "Rev", "T", "action",
                "verdict_status", "outcome", "outcome_metrics", "outcome_horizon", "outcome_notes", "outcome_timestamp"]
        record = dict(zip(keys, row))
        record["context"] = json.loads(record["context"])
        record["confidence_report"] = json.loads(record["confidence_report"])
        if record["outcome_metrics"]:
            record["outcome_metrics"] = json.loads(record["outcome_metrics"])
        # Les 3 canaux de vérité terrain, réunis pour l'audit.
        record["reviews"] = self.get_reviews(decision_id)
        record["arbitration"] = self.get_arbitration(decision_id)
        return record

    def all_decisions(self):
        c = self.conn.cursor()
        c.execute("SELECT id, timestamp, context, confidence_report, R, I, Rev, T, action FROM decisions")
        return c.fetchall()

