import pytest

from app.compute_confidence import FCSV, compute_confidence_state, geometric_aggregation
from app.config import ALPHA_WEIGHTS, GATE_EPSILON
from app.governance import compute_T, decide_action

SPEC = {}  # normalize_spec par défaut suffit pour ces cas (raw scalaires 0-4)


def test_gate_unknown_when_g_zero():
    csv_norm = {"Q": 1, "D": 1, "K": 1, "X": 1, "E": 1, "S": 1, "M": 1, "G": 0}
    assert compute_confidence_state(csv_norm) == "UNKNOWN"


def test_gate_conflicted_when_d_zero():
    csv_norm = {"Q": 1, "D": 0, "K": 1, "X": 1, "E": 1, "S": 1, "M": 1, "G": 1}
    assert compute_confidence_state(csv_norm) == "CONFLICTED"


def test_gate_degraded_when_fundamental_low():
    csv_norm = {"Q": 0.1, "D": 1, "K": 1, "X": 1, "E": 1, "S": 1, "M": 1, "G": 1}
    assert compute_confidence_state(csv_norm) == "DEGRADED"


def test_gate_fragile():
    csv_norm = {"Q": 1, "D": 1, "K": 1, "X": 1, "E": 0.3, "S": 1, "M": 1, "G": 1}
    assert compute_confidence_state(csv_norm) == "FRAGILE"


def test_gate_robust_requires_all_high():
    csv_norm = {d: 0.8 for d in ["Q", "D", "K", "X", "E", "S", "M", "G"]}
    assert compute_confidence_state(csv_norm) == "ROBUST"


def test_gate_stable_default():
    csv_norm = {"Q": 0.6, "D": 0.6, "K": 0.6, "X": 0.6, "E": 0.6, "S": 0.6, "M": 0.6, "G": 0.6}
    assert compute_confidence_state(csv_norm) == "STABLE"


def test_invariant_c_never_exceeds_cap():
    csv_raw = {d: 4 for d in ["Q", "D", "K", "X", "E", "S", "M", "G"]}
    result = FCSV(csv_raw, SPEC)
    assert result["c"] <= result["c_cap"] + 1e-9


def test_t_independent_of_c():
    """Invariant central : T ne dépend jamais de C (dT/dC = 0).
    Vérifié structurellement, pas seulement comportementalement :
    la signature de compute_T ne doit accepter aucun paramètre de
    confiance. L'ancienne version de ce test appelait juste deux fois
    la fonction avec les mêmes arguments — elle passait même si C
    avait été ajouté comme paramètre optionnel."""
    import inspect
    params = set(inspect.signature(compute_T).parameters)
    assert params == {"R", "I", "Rev"}, (
        f"compute_T ne doit dépendre que de R, I, Rev — signature vue : {params}"
    )
    # Et comportementalement : mêmes entrées -> même sortie.
    assert compute_T(0.9, 0.9, 0.0) == compute_T(0.9, 0.9, 0.0)


def test_alpha_weights_sum_to_one():
    """Garde-fou : une moyenne géométrique pondérée exige sum(w) == 1.
    Une somme != 1 biaise C d'un exposant égal à la somme des poids
    (biais silencieux, historiquement 1.1 -> sous-estimation de C)."""
    assert sum(ALPHA_WEIGHTS.values()) == pytest.approx(1.0, abs=1e-12)


def test_geometric_mean_is_exact_on_uniform_input():
    """Toutes les dimensions à 0.5 -> C brut doit valoir exactement 0.5
    (pas 0.5^1.1). Échoue avec des poids non normalisés."""
    csv_raw = {d: 2 for d in ["Q", "D", "K", "X", "E", "S", "M", "G"]}  # 2/4 = 0.5
    result = FCSV(csv_raw, SPEC)
    assert result["c_raw"] == pytest.approx(0.5, abs=1e-9)


def test_gate_epsilon_float_noise():
    """Un epsilon flottant (source continue) doit déclencher le gate
    comme un zéro exact — pas de fail-open sur == 0.0."""
    base = {"Q": 1, "D": 1, "K": 1, "X": 1, "E": 1, "S": 1, "M": 1}
    assert compute_confidence_state({**base, "G": GATE_EPSILON / 2}) == "UNKNOWN"
    assert compute_confidence_state({**base, "G": 0.0}) == "UNKNOWN"
    assert compute_confidence_state({**base, "D": GATE_EPSILON / 2, "G": 1}) == "CONFLICTED"


def test_gate_near_zero_gap_is_degraded_not_stable():
    """G quasi nul mais non nul (ex: 0.1) : la couverture des lacunes
    est critique -> DEGRADED, jamais STABLE. Avant correctif : STABLE
    avec C=0.46 (fail-open démontré)."""
    csv_norm = {"Q": 1, "D": 1, "K": 1, "X": 1, "E": 1, "S": 1, "M": 1, "G": 0.1}
    assert compute_confidence_state(csv_norm) == "DEGRADED"


def test_maximal_t_forces_escalate_even_with_high_c():
    """Même à C proche de 1.0, T maximal impose une sortie ESCALATE ou STOP,
    jamais ACT — voir Manifeste HIBOU-OS, Partie IX (invariant de prudence).
    State ROBUST (confiance fiable) -> ESCALATE, pas STOP."""
    T = compute_T(R=1.0, I=1.0, Rev=0.0)
    assert T >= 0.9
    assert decide_action(T, C=0.999, confidence_state="ROBUST") == "ESCALATE"


def test_maximal_t_with_broken_confidence_forces_stop():
    """STOP — état de sortie explicite depuis la décision du 21 sept. 2026.
    Critère VALIDÉ le 26 sept. 2026 : State UNKNOWN/CONFLICTED au palier
    maximal -> STOP plutôt qu'ESCALATE (rien de fiable à transmettre)."""
    T = compute_T(R=1.0, I=1.0, Rev=0.0)
    assert T >= 0.9
    assert decide_action(T, C=0.1, confidence_state="UNKNOWN") == "STOP"
    assert decide_action(T, C=0.1, confidence_state="CONFLICTED") == "STOP"


def test_maximal_t_never_returns_act_verify_recommend():
    """Invariant : au palier maximal, seules STOP et ESCALATE sont
    admissibles en sortie — jamais ACT/VERIFY/RECOMMEND."""
    T = compute_T(R=1.0, I=1.0, Rev=0.0)
    for state in ["UNKNOWN", "CONFLICTED", "DEGRADED", "FRAGILE", "STABLE", "ROBUST"]:
        assert decide_action(T, C=0.9, confidence_state=state) in ("STOP", "ESCALATE")


def test_broken_confidence_forces_stop_at_any_t():
    """Extension tranchée le 28 sept. 2026 : le critère STOP-vs-ESCALATE ne
    dépend pas de T (symétrie avec dT/dC = 0). UNKNOWN/CONFLICTED -> STOP
    à tout niveau de risque — le rationnel "arbitrage humain sur du bruit"
    vaut hors palier maximal aussi."""
    for T in [0.05, 0.3, 0.5, 0.75, 0.85, 0.95]:
        assert decide_action(T, C=0.9, confidence_state="UNKNOWN") == "STOP"
        assert decide_action(T, C=0.1, confidence_state="CONFLICTED") == "STOP"


def test_known_states_unchanged_by_stop_extension():
    """États connus : comportement par bandes inchangé par l'extension,
    sauf les deux évolutions doctrinales du treillis 5+2 (30 sept. 2026),
    documentées dans les tests dédiés ci-dessous."""
    assert decide_action(0.2, C=0.9, confidence_state="STABLE") == "ACT"
    assert decide_action(0.2, C=0.1, confidence_state="STABLE") == "OBSERVE"
    assert decide_action(0.95, C=0.9, confidence_state="DEGRADED") == "ESCALATE"
    assert decide_action(0.95, C=0.9, confidence_state=None) == "ESCALATE"


def test_observe_floor_replaces_verify_below_floor():
    """Treillis 5+2 (30 sept. 2026) : sous le plancher de confiance, il n'y
    a rien d'assez solide pour agir NI pour vérifier quoi que ce soit de
    précis — OBSERVE remplace VERIFY. Vérifier présuppose une prise à
    confronter ; sous le plancher, il n'y a que du bruit à observer."""
    for T in [0.1, 0.3, 0.5, 0.75, 0.85]:
        assert decide_action(T, C=0.1, confidence_state="STABLE") == "OBSERVE"
        assert decide_action(T, C=0.29, confidence_state="STABLE") == "OBSERVE"
    # à la frontière, le niveau supérieur reprend
    assert decide_action(0.2, C=0.3, confidence_state="STABLE") == "VERIFY"
    assert decide_action(0.5, C=0.3, confidence_state="STABLE") == "VERIFY"


def test_maximal_t_takes_precedence_over_observe_floor():
    """Au palier maximal, l'arbitrage humain prime sur l'observation passive :
    même sous le plancher de confiance (état connu), on ESCALATE."""
    assert decide_action(0.95, C=0.1, confidence_state="STABLE") == "ESCALATE"
    assert decide_action(0.95, C=0.1, confidence_state="DEGRADED") == "ESCALATE"


def test_degraded_caps_high_t_band():
    """Treillis 5+2 (30 sept. 2026) : à T élevé, la pleine autonomie (ACT)
    n'est jamais accordée — au mieux DEGRADED (capacité réduite). Même à
    C = 0.99 : la prudence T ne se négocie pas contre de la confiance."""
    for T in [0.7, 0.75, 0.85, 0.89]:
        assert decide_action(T, C=0.99, confidence_state="STABLE") == "DEGRADED"
        assert decide_action(T, C=0.85, confidence_state="ROBUST") == "DEGRADED"
        assert decide_action(T, C=0.5, confidence_state="STABLE") == "RECOMMEND"


def test_lattice_membership():
    """Toutes les sorties de h(T, C) appartiennent au treillis 5+2."""
    niveaux = {"OBSERVE", "RECOMMEND", "VERIFY", "DEGRADED", "ACT"}
    laterales = {"ESCALATE", "STOP"}
    for T in [round(x * 0.05, 2) for x in range(21)]:
        for C in [round(x * 0.05, 2) for x in range(21)]:
            for state in ["UNKNOWN", "CONFLICTED", "DEGRADED", "FRAGILE", "STABLE", "ROBUST", None]:
                assert decide_action(T, C, confidence_state=state) in niveaux | laterales


def test_monotonicity_in_c_within_bins():
    """Dans chaque bande de T, plus de confiance ne donne jamais MOINS
    d'autonomie (monotonie du treillis)."""
    rang = {"OBSERVE": 0, "RECOMMEND": 1, "VERIFY": 2, "DEGRADED": 3, "ACT": 4,
            "ESCALATE": 5, "STOP": 5}
    for T in [0.1, 0.5, 0.8]:
        sorties = [decide_action(T, C / 100, confidence_state="STABLE") for C in range(0, 101, 5)]
        rangs = [rang[s] for s in sorties]
        assert rangs == sorted(rangs), f"non-monotone à T={T} : {sorties}"


def test_high_t_band_c_still_matters():
    """Régression pour le bug corrigé : dans la bande T élevé, C doit
    changer le résultat (DEGRADED vs RECOMMEND depuis le treillis 5+2
    du 30 sept. 2026 — ACT n'est plus accordé à T élevé), pas rester
    figé sur une seule sortie."""
    T = 0.75  # bande "eleve" : 0.7 <= T < 0.9
    assert decide_action(T, C=0.9) == "DEGRADED"
    assert decide_action(T, C=0.5) == "RECOMMEND"
