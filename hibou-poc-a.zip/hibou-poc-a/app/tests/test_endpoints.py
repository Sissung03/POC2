import os
import tempfile

import pytest

os.environ["HIBOU_DB"] = tempfile.mktemp(suffix=".db")

from app.app import app  # noqa: E402


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c


def test_compute_confidence_endpoint(client):
    payload = {"csv_raw": {d: 4 for d in ["Q", "D", "K", "X", "E", "S", "M", "G"]}}
    resp = client.post("/compute_confidence", json=payload)
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["state"] == "ROBUST"
    assert data["c"] <= data["c_cap"] + 1e-9


def test_submit_decision_context_endpoint(client):
    payload = {
        "context": {"scenario": "paiement_irreversible"},
        "R": 0.95, "I": 1.0, "Rev": 0.0,
        "csv_raw": {d: 4 for d in ["Q", "D", "K", "X", "E", "S", "M", "G"]},
    }
    resp = client.post("/submit_decision_context", json=payload)
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["A"] == "ESCALATE"  # T maximal attendu pour ce scénario
    assert "decision_id" in data


def test_outcome_and_get_decision_roundtrip(client):
    submit = client.post("/submit_decision_context", json={
        "context": {"scenario": "agent_conversationnel"},
        "R": 0.2, "I": 0.1, "Rev": 0.9,
        "csv_raw": {d: 3 for d in ["Q", "D", "K", "X", "E", "S", "M", "G"]},
    })
    decision_id = submit.get_json()["decision_id"]

    # avant tout outcome : verdict en attente
    before = client.get(f"/decision/{decision_id}")
    assert before.status_code == 200
    assert before.get_json()["verdict_status"] == "EN_ATTENTE"

    # un canal de vérité terrain rapporte un résultat
    out = client.post("/outcome", json={
        "decision_id": decision_id, "outcome": "SUCCESS",
        "metrics": {"latency_ms": 120}, "horizon": "COURT_DELAI",
    })
    assert out.status_code == 200
    assert out.get_json()["verdict_status"] == "SUIVI"

    after = client.get(f"/decision/{decision_id}")
    data = after.get_json()
    assert data["verdict_status"] == "SUIVI"
    assert data["outcome"] == "SUCCESS"
    assert data["outcome_horizon"] == "COURT_DELAI"


def test_outcome_unknown_decision_returns_404(client):
    resp = client.post("/outcome", json={"decision_id": "does-not-exist", "outcome": "SUCCESS"})
    assert resp.status_code == 404


def test_get_decision_unknown_returns_404(client):
    resp = client.get("/decision/does-not-exist")
    assert resp.status_code == 404
