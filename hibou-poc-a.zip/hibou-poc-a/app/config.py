# config.py
# Paramètres gouvernés — version POC (ancrages initiaux, NON calibrés).
# Toute modification devrait être journalisée (voir Document Technique v0,
# Partie 5 : calibration gouvernée, jamais en temps réel).

# Poids relatifs bruts des 8 dimensions du CSV dans l'agrégation
# géométrique. Les rapports entre dimensions sont l'hypothèse de travail ;
# la normalisation ci-dessous garantit que la somme vaut exactement 1.0,
# condition mathématique d'une vraie moyenne géométrique pondérée.
# (Correctif : la somme valait 1.1, ce qui sous-estimait systématiquement C
#  d'un exposant 1.1 — biais silencieux, direction fail-closed mais non
#  documenté. Voir docs/decisions_a_trancher.md.)
_ALPHA_RAW = {
    "Q": 0.15, "D": 0.15, "K": 0.15, "X": 0.15,
    "E": 0.15, "S": 0.15, "M": 0.10, "G": 0.10,
}
_ALPHA_TOTAL = sum(_ALPHA_RAW.values())
ALPHA_WEIGHTS = {k: v / _ALPHA_TOTAL for k, v in _ALPHA_RAW.items()}

# Tolérance du "zéro" pour les hard gates G et D.
# Les gates testaient `G == 0.0` en égalité flottante stricte : toute
# source continue renvoyant un epsilon (ex: 0.0004) au lieu d'un zéro
# exact faisait rater le gate silencieusement — et un G quasi nul mais
# non nul donnait STABLE au lieu d'UNKNOWN (fail-open démontré).
# Règle : `<= GATE_EPSILON` = "donnée absente". Tout normalisateur
# continu DOIT émettre exactement 0.0 pour "absent" (voir
# docs/dimensions_csv.md, contrat de normalisation).
GATE_EPSILON = 1e-9

STATE_CAP = {
    "UNKNOWN": 0.20,
    "CONFLICTED": 0.35,
    "DEGRADED": 0.55,
    "FRAGILE": 0.70,
    "STABLE": 0.85,
    "ROBUST": 1.00,
}

THRESHOLDS = {
    "fundamental_low": 0.25,
    "fragile": 0.50,
    "robust": 0.75,
}

# Poids de la première forme concrète de T = f(R, I, Rev).
# Hypothèse de travail — non calibrée.
T_WEIGHTS = {
    "R": 0.6,
    "I": 0.3,
    "REV_COMPLEMENT": 0.1,  # applique sur (1 - Rev)
}

# Bornes de l'automate A = h(T, C) — brouillon de travail.
# Voir Document Technique v0, Partie 5.
T_BINS = {
    "maximal": 0.9,
    "eleve": 0.7,
    "modere": 0.4,
}

# STOP comme etat de sortie explicite de h(T,C) — decision validee le 21
# sept. 2026 (Manifeste HIBOU-OS, Partie VII.7).
# Critere STOP vs ESCALATE au palier maximal — VALIDE (tranche par Denard
# le 26 sept. 2026, a confirmer avec Roqia lors de la calibration
# empirique) : la distinction n'est pas le niveau de risque (T s'en
# occupe deja) mais l'existence d'une base fiable a transmettre a un
# humain. Si le Confidence State est UNKNOWN ou CONFLICTED (hard gate
# G=0 ou D=0 : aucune donnee de contexte, ou signaux contradictoires),
# la pipeline de confiance a elle-meme echoue -> escalader reviendrait a
# demander un arbitrage humain sur du bruit -> STOP (arret immediat,
# fail-safe autonome, esprit IEC 61508). Si le State est connu (meme
# DEGRADED ou FRAGILE), une base degradee mais reelle existe pour un
# arbitrage humain -> ESCALATE.
STOP_CONFIDENCE_STATES = {"UNKNOWN", "CONFLICTED"}

C_ACT_THRESHOLD_LOW_T = 0.5     # sous T < 0.4
C_ACT_THRESHOLD_MID_T = 0.6     # sous 0.4 <= T < 0.7
C_ACT_THRESHOLD_HIGH_T = 0.85   # sous 0.7 <= T < 0.9

# Plancher de confiance du niveau OBSERVE — ANCRAGE SYMBOLIQUE, NON CALIBRÉ.
# Sous ce plancher, la base épistémique est trop mince pour agir ET pour
# vérifier quoi que ce soit de précis : vérifier présuppose une prise à
# laquelle confronter une source ; sous le plancher, il n'y a que du bruit
# à observer. La valeur exacte (0.3) sera déterminée par la calibration
# empirique (cycle 1) — voir docs/protocole_calibration.md.
C_OBSERVE_FLOOR = 0.3
