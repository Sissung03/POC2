# demo/dashboard.py
# Dashboard Streamlit — visualise les datasets synthétiques et les
# verdicts F(CSV). Outil de démonstration et de test de cohérence,
# pas de calibration (voir Document Technique v0, Partie 10).
#
# Usage :
#   1. Démarrer le service : flask run --host=0.0.0.0 --port=8080
#   2. Générer un dataset : python3 scripts/generate_dataset.py --mode C1 --n 300
#   3. streamlit run demo/dashboard.py

import glob
import json
import os

import pandas as pd
import requests
import streamlit as st

API_URL = "http://localhost:8080/compute_confidence"

st.set_page_config(page_title="HIBOU Dashboard", layout="wide")
st.title("🦉 HIBOU — Dashboard Métacognitif")
st.write("Visualisation des datasets synthétiques et des verdicts F(CSV). Outil de démonstration — pas un instrument de calibration.")

# ---------------- Chargement du dataset ----------------
available = sorted(glob.glob("decisions_*.json")) + sorted(glob.glob("app/sample_data/*.json"))
if not available:
    st.warning("Aucun dataset trouvé. Génère-en un avec : python3 scripts/generate_dataset.py --mode C1 --n 300")
    st.stop()

dataset_path = st.selectbox("Choisir un dataset", available)
with open(dataset_path, "r") as f:
    data = json.load(f)

df = pd.DataFrame(data)
st.subheader(f"Dataset chargé : {dataset_path}")
st.write(f"Nombre de décisions : {len(df)}")


# ---------------- Calcul des Confidence States ----------------
@st.cache_data
def compute_all_confidence(records):
    results = []
    for row in records:
        payload = {"csv_raw": row["csv_raw"]}
        try:
            r = requests.post(API_URL, json=payload, timeout=5).json()
        except Exception:
            r = {"state": "ERROR", "c": 0, "c_raw": 0, "c_cap": 0}
        results.append(r)
    return results

st.write("Calcul des Confidence States...")
results = compute_all_confidence(df.to_dict("records"))

df["State"] = [r.get("state") for r in results]
df["C_raw"] = [r.get("c_raw") for r in results]
df["C"] = [r.get("c") for r in results]
df["C_cap"] = [r.get("c_cap") for r in results]

# ---------------- Statistiques globales ----------------
st.subheader("📊 Distribution des Confidence States")
st.bar_chart(df["State"].value_counts())

st.subheader("📈 C_raw vs C (effet du plafonnement)")
st.line_chart(df[["C_raw", "C"]])

violations = df[df["C"] > df["C_cap"] + 1e-9]
if len(violations) > 0:
    st.error(f"⚠ Invariant C ≤ Cap(State) violé sur {len(violations)} décision(s) — à investiguer avant toute démo.")
else:
    st.success("Invariant C ≤ Cap(State) respecté sur 100% du dataset chargé.")

# ---------------- Vue par scénario ----------------
st.subheader("🔍 Analyse par scénario")
scenario = st.selectbox("Choisir un scénario", df["context"].apply(lambda x: x["scenario"]).unique())
scenario_df = df[df["context"].apply(lambda x: x["scenario"]) == scenario]
st.write(f"Décisions dans ce scénario : {len(scenario_df)}")
st.bar_chart(scenario_df["State"].value_counts())

# ---------------- Inspecteur de décision ----------------
st.subheader("🧪 Inspecteur de décision")
decision_id = st.selectbox("Choisir une décision", df["id"].unique())
decision_row = df[df["id"] == decision_id].iloc[0]

st.write("### Contexte")
st.json(decision_row["context"])

st.write("### CSV brut")
st.json(decision_row["csv_raw"])

st.write("### Confidence State et plafonnement")
st.write({
    "State": decision_row["State"],
    "C_raw": float(decision_row["C_raw"]),
    "C": float(decision_row["C"]),
    "Cap": float(decision_row["C_cap"]),
})

# ---------------- Hard gates ----------------
st.subheader("🚨 Hard gates déclenchés")
csv = decision_row["csv_raw"]
hard_gates = []

def scalar(v):
    return v if isinstance(v, (int, float)) else 4  # dict Q -> traité ailleurs par normalize_value

if scalar(csv.get("G", 4)) == 0:
    hard_gates.append("UNKNOWN — G=0 (gap critique)")
if scalar(csv.get("D", 4)) == 0:
    hard_gates.append("CONFLICTED — D=0 (contradiction critique)")
if scalar(csv.get("Q", 4)) < 1 or scalar(csv.get("K", 4)) < 1 or scalar(csv.get("X", 4)) < 1:
    hard_gates.append("DEGRADED — Q/K/X faibles")
if scalar(csv.get("S", 4)) < 2 or scalar(csv.get("E", 4)) < 2 or scalar(csv.get("M", 4)) < 2:
    hard_gates.append("FRAGILE — S/E/M faibles")

if not hard_gates:
    st.success("Aucun hard gate déclenché.")
else:
    st.error("Hard gates déclenchés :")
    for hg in hard_gates:
        st.write(f"- {hg}")

st.write("---")
st.write("HIBOU Dashboard — POC Métacognition — outil de démonstration, non de calibration")
