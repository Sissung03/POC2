# scripts/generate_dataset.py
# Génère des décisions synthétiques pour tester la couverture logique du
# pipeline FCSV (tous les Confidence States, cas limites, cas adverses).
#
# Statut : outil de test de cohérence, PAS un substitut à la calibration
# empirique — voir Document Technique v0, Partie 10 : le protocole de
# calibration réelle repose sur quelques centaines de décisions réelles
# tracées via SCI-MEM, pas sur ce jeu synthétique.
#
# Usage :
#   python3 scripts/generate_dataset.py --mode C1 --n 300
#   python3 scripts/generate_dataset.py --mode C1 --mode C2 --mode C3 --n 300

import argparse
import json
import random
import uuid

STATES = ["UNKNOWN", "CONFLICTED", "DEGRADED", "FRAGILE", "STABLE", "ROBUST"]

SCENARIOS = [
    "paiement_irreversible", "agent_conversationnel", "contradiction_sources",
    "preuve_faible", "preuve_forte", "contexte_incoherent",
    "raisonnement_fragile", "robustesse_totale", "gaps_critiques",
    "decision_quotidienne",
]


def decision_id():
    return "d-" + str(uuid.uuid4())[:8]


def rand(low, high):
    return round(random.uniform(low, high), 2)


def csv_for_state(state, noisy=False, adversarial=False):
    dims = ["Q", "D", "K", "X", "E", "S", "M", "G"]

    if state == "ROBUST":
        base = {k: random.randint(3, 4) for k in dims}
    elif state == "FRAGILE":
        base = {
            "Q": random.randint(2, 4), "D": random.randint(2, 4), "K": random.randint(2, 4),
            "X": random.randint(2, 4), "E": random.randint(0, 2), "S": random.randint(0, 2),
            "M": random.randint(1, 3), "G": random.randint(2, 4),
        }
    elif state == "DEGRADED":
        base = {
            "Q": random.randint(0, 1), "D": random.randint(1, 3), "K": random.randint(0, 1),
            "X": random.randint(0, 1), "E": random.randint(1, 3), "S": random.randint(1, 3),
            "M": random.randint(1, 3), "G": random.randint(1, 3),
        }
    elif state == "CONFLICTED":
        base = {
            "Q": random.randint(2, 4), "D": 0, "K": random.randint(2, 4), "X": random.randint(2, 4),
            "E": random.randint(2, 4), "S": random.randint(2, 4), "M": random.randint(2, 4),
            "G": random.randint(2, 4),
        }
    elif state == "UNKNOWN":
        base = {
            "Q": random.randint(2, 4), "D": random.randint(2, 4), "K": random.randint(2, 4),
            "X": random.randint(2, 4), "E": random.randint(2, 4), "S": random.randint(2, 4),
            "M": random.randint(2, 4), "G": 0,
        }
    else:  # STABLE
        base = {k: random.randint(2, 4) for k in dims}

    if noisy:
        for k in base:
            if random.random() < 0.2:
                base[k] = max(0, min(4, base[k] + random.choice([-1, 1])))

    if adversarial:
        if random.random() < 0.1:
            base["D"] = 0
        if random.random() < 0.1:
            base["G"] = 0
        if random.random() < 0.1:
            base["M"] = 0

    return base


def generate_entry(state, scenario, mode):
    noisy = mode in ["C2", "C3"]
    adversarial = mode == "C3"
    return {
        "id": decision_id(),
        "context": {"scenario": scenario, "summary": f"{scenario} / {state} / {mode}"},
        "csv_raw": csv_for_state(state, noisy=noisy, adversarial=adversarial),
        "R": rand(0.0, 1.0),
        "I": rand(0.0, 1.0),
        "Rev": rand(0.0, 1.0),
    }


def generate_dataset(mode, n):
    data = []

    if mode == "C1":
        # équilibré par Confidence State — utile pour vérifier la couverture logique
        per_state = n // len(STATES)
        for state in STATES:
            for _ in range(per_state):
                data.append(generate_entry(state, random.choice(SCENARIOS), mode))

    elif mode == "C2":
        # distribution réaliste : plus de FRAGILE/STABLE, moins de ROBUST/UNKNOWN
        weights = {"UNKNOWN": 0.05, "CONFLICTED": 0.10, "DEGRADED": 0.15,
                   "FRAGILE": 0.25, "STABLE": 0.30, "ROBUST": 0.15}
        states_list = []
        for s, w in weights.items():
            states_list += [s] * int(w * n)
        while len(states_list) < n:
            states_list.append("STABLE")
        random.shuffle(states_list)
        for state in states_list:
            data.append(generate_entry(state, random.choice(SCENARIOS), mode))

    elif mode == "C3":
        # adverse : bruit + anomalies volontaires, pour stress-tester les hard gates
        weights = {"UNKNOWN": 0.10, "CONFLICTED": 0.15, "DEGRADED": 0.20,
                   "FRAGILE": 0.20, "STABLE": 0.20, "ROBUST": 0.15}
        states_list = []
        for s, w in weights.items():
            states_list += [s] * int(w * n)
        while len(states_list) < n:
            states_list.append("FRAGILE")
        random.shuffle(states_list)
        for state in states_list:
            data.append(generate_entry(state, random.choice(SCENARIOS), mode))

    else:
        raise ValueError("mode must be one of: C1, C2, C3")

    return data


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", action="append", choices=["C1", "C2", "C3"],
                         default=None, help="Peut être répété (ex: --mode C1 --mode C2)")
    parser.add_argument("--n", type=int, default=300,
                         help="Taille du jeu par mode (défaut : 300, suffisant pour un test de cohérence — voir Document Technique v0, Partie 10)")
    args = parser.parse_args()
    modes = args.mode or ["C1", "C2", "C3"]

    for mode in modes:
        dataset = generate_dataset(mode, args.n)
        filename = f"decisions_{args.n}_{mode}.json"
        with open(filename, "w") as f:
            json.dump(dataset, f, indent=2)
        print(f"✔ Dataset {mode} généré : {filename} ({len(dataset)} décisions)")
