# HIBOU POC A — SCI-META minimal + Kernel façade

> **Intégration du 4 oct. 2026.** Ce dépôt fusionne le patch de Cooper
> (30 sept. 2026 — treillis 5+2, canaux /review et /arbitration, deux
> correctifs de bugs) dans la version canonique livrée. `docs/protocole_calibration.md`
> a été remplacé par la version v1.1 FINAL (tranchée le 30 sept. 2026).
> 37 tests verts (vérifiés hors pytest, l'environnement n'ayant pas accès
> au registre de paquets — voir note en fin de fichier).

Démontre le pipeline CSV → State → C et l'invariant constitutionnel
`C ≤ Cap(State)`, ainsi qu'une première version concrète (non calibrée)
de `T = f(R, I, Rev)` et du treillis canonique 5+2 `A = h(T, C, State)`
(`OBSERVE < RECOMMEND < VERIFY < DEGRADED < ACT` + `ESCALATE`/`STOP`
latéraux — voir `docs/decisions_a_trancher.md`).

**Statut : hypothèse de travail.** Les poids (`ALPHA_WEIGHTS`), les seuils
(`THRESHOLDS`), les plafonds (`STATE_CAP`) et la formule de `T` sont des
ancrages initiaux — voir `app/config.py`. Rien ici n'est calibré
empiriquement ; ce dépôt sert à prouver que le mécanisme fonctionne, pas
qu'il est juste.

## Quickstart (local)

```bash
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
export FLASK_APP=app/app.py
flask run --host=0.0.0.0 --port=8080
```

## Endpoints

- `POST /compute_confidence` → `{ "csv_raw": {...} }`
- `POST /submit_decision_context` → `{ "context": {...}, "R": 0-1, "I": 0-1, "Rev": 0-1, "csv_raw": {...} }`
- `POST /outcome` → `{ "decision_id": "...", "outcome": "SUCCESS|FAIL|PARTIAL", "metrics": {...}, "horizon": "IMMEDIAT|COURT_DELAI|LONG_DELAI" }` — canal 1 de vérité terrain (le monde répond) ; met à jour `verdict_status` sans jamais ajuster T ou les hard gates en direct
- `POST /review` → `{ "decision_id": "...", "reviewer": "...", "state_verdict": "CONFIRME|CORRIGE", "action_verdict": "CONFIRME|CORRIGE", ... }` — canal 2 (revue experte offline du processus)
- `POST /arbitration` → `{ "decision_id": "...", "resolver": "...", "resolution": "ACT|STOP|MODIFIE|DELEGUE", "agreement": "ACCORD|DESACCORD_PARTIEL|DESACCORD", ... }` — canal 3 (résolution humaine des escalades)
- `GET /decision/{decision_id}` → DecisionRecord complet : outcome + reviews + arbitration (les 3 canaux réunis)

## Générer un dataset synthétique de test

```bash
python3 scripts/generate_dataset.py --mode C1 --mode C2 --mode C3 --n 300
```

Trois profils : C1 (équilibré par Confidence State, pour vérifier la
couverture logique des hard gates), C2 (distribution réaliste), C3
(adverse — bruit et anomalies volontaires pour stress-tester le pipeline).

**Ce jeu synthétique sert à tester la cohérence du mécanisme, pas à le
calibrer.** La calibration réelle (Document Technique v0, Partie 10)
repose sur quelques centaines de décisions réelles tracées via SCI-MEM,
pas sur des données générées.

## Dashboard de démonstration

```bash
flask run --host=0.0.0.0 --port=8080 &
streamlit run demo/dashboard.py
```

Visualise la distribution des Confidence States, l'effet du plafonnement
(C_raw vs C), un inspecteur de décision, et vérifie l'invariant
`C ≤ Cap(State)` sur l'ensemble du dataset chargé.

## Tests

```bash
pytest app/tests -v
```

## Démo rapide

```bash
bash demo/demo_script.sh
```

## Livrables inclus

- Microservice SCI-META (`compute_confidence.py`)
- Façade Kernel minimale (`app.py`)
- Traçabilité SCI-MEM (`storage.py`, SQLite par défaut — voir `HIBOU_DB` dans l'environnement pour changer de fichier)
- 2 décisions d'exemple (`app/sample_data/decisions_sample.json`) — à étoffer vers quelques dizaines pour un premier test de cohérence (voir le Document Technique v0, Partie 10 : pas besoin de 500 dès ce stade)
- Tests unitaires pour les hard gates et les endpoints

## Ce qui a été corrigé par rapport à la version reçue

1. Identifiants corrompus lors d'un transfert précédent (`csvraw` → `csv_raw`,
   `computeconfidencestate` → `compute_confidence_state`, etc.) et opérateurs
   de multiplication manquants dans `normalize_value`.
2. Bug dans `h(T, C)` : la bande `T ∈ [0.7, 0.9)` retournait `RECOMMEND`
   quelle que soit la valeur de `C`. Corrigé pour que `C` influence toujours
   le comportement, sauf au palier maximal où `ESCALATE` est inconditionnel
   par construction (voir Manifeste HIBOU-OS, Partie IX).
3. `dashboard.py` reçu séparément était corrompu plus sévèrement (guillemets
   français `« »` à la place des guillemets Python, mots-clés capitalisés,
   `results.append®` au lieu de `results.append(r)`) — réécrit entièrement
   dans `demo/dashboard.py`, aligné sur les noms de champs réels du service
   (`csv_raw`, `c_raw`, `c`, `c_cap`, `state`).

## Correctifs d'audit — patch Cooper (28 sept. 2026)

Audit externe du PoC : 2 bugs réels corrigés, tests renforcés, docs ajoutées.
Détail : `docs/decisions_a_trancher.md`.

4. **Poids ALPHA non normalisés (bug silencieux).** La somme valait 1,1 au
   lieu de 1,0 — la "moyenne géométrique pondérée" n'en était pas une et
   sous-estimait systématiquement C (ex : 0,4665 au lieu de 0,5 avec toutes
   les dimensions à 0,5). Les poids sont désormais normalisés dans
   `config.py` (rapports relatifs inchangés) et un test garde l'invariant
   `sum == 1.0`.
5. **Gates en égalité flottante stricte (fail-open démontré).** `G == 0.0`
   ratait le gate dès qu'une source continue renvoyait un epsilon :
   G=0,0004 donnait STABLE avec C=0,46 au lieu d'UNKNOWN avec C capé à 0,20.
   Les gates utilisent désormais `<= GATE_EPSILON`, et G rejoint Q/K/X dans
   les fondamentaux du gate DEGRADED (un G quasi nul ne donne plus STABLE).
6. **Test `test_t_independent_of_c` renforcé.** L'ancienne version appelait
   juste deux fois la fonction avec les mêmes arguments — elle passait même
   si C avait été ajouté comme paramètre. Elle inspecte désormais la
   signature de `compute_T` et exige exactement `{R, I, Rev}`.
7. **Dépendances nettoyées.** `requirements.txt` ne contient plus que les
   paquets réellement importés (retirés : SQLAlchemy, pydantic, gunicorn).
8. **Docs ajoutées.** `docs/dimensions_csv.md` : définitions des
   8 dimensions + contrat de normalisation (validées par Denard le
   28 sept. 2026 — contrat sémantique officiel du CSV).
   `docs/decisions_a_trancher.md` : 3 points de design à trancher avant
   calibration (SEEK manquant, UNKNOWN/CONFLICTED à T non maximal,
   authentification pré-déploiement).
9. **Protocole de calibration (cycle 1).** `docs/protocole_calibration.md` :
   principes non négociables, collecte (~150 décisions réelles via SCI-MEM),
   métriques hors-ligne, ordre d'ajustement, gouvernance versionnée,
   critères de sortie.

## Mise à jour du 26 sept. 2026 — STOP comme état de sortie explicite

Décision validée par Denard (Manifeste HIBOU-OS, Partie VII.7) : `STOP` doit
être un état de sortie explicite de `A = h(T, C)`, au même titre
qu'`ACT`/`VERIFY`/`RECOMMEND`/`ESCALATE` — il n'existait auparavant que
parmi les 5 états de la Metacognition (`STOP/SEEK/VERIFY/ESCALATE/ACT`),
pas dans l'automate.

**Ce qui a changé** :
- `decide_action(T, C)` devient `decide_action(T, C, confidence_state)`.
- Au palier maximal (`T ≥ 0.9`), la sortie est maintenant `STOP` **ou**
  `ESCALATE` — jamais `ACT`/`VERIFY`/`RECOMMEND` — au lieu d'`ESCALATE`
  inconditionnel.

**Critère STOP vs ESCALATE — VALIDÉ le 26 sept. 2026** (tranché par Denard,
à confirmer avec Roqia lors de la calibration empirique) : si le
Confidence State lui-même est `UNKNOWN` ou `CONFLICTED` (hard gate `G=0`
ou `D=0`), la pipeline de confiance a échoué — rien de fiable à
transmettre à un humain → `STOP` (arrêt immédiat, fail-safe autonome).
Si le State est connu, même dégradé → `ESCALATE` (transmission de
contexte pour arbitrage humain). Voir `STOP_CONFIDENCE_STATES` dans
`config.py`.

3 tests ajoutés dans `test_compute_confidence.py` couvrent ce comportement
et l'invariant "jamais ACT/VERIFY/RECOMMEND au palier maximal".

## Extension du 28 sept. 2026 — critère STOP indépendant de T

Tranché par Cooper sur délégation de Denard (à revoir avec Roqia en
calibration) : le critère STOP-vs-ESCALATE ne dépend plus de T — symétrie
avec l'invariant d'indépendance (dT/dC = 0). Si le State est `UNKNOWN` ou
`CONFLICTED` → `STOP` immédiat, **quelle que soit la bande de T**
(retour anticipé dans `decide_action`, avant les bandes). Au palier
maximal avec un State connu → `ESCALATE` (inchangé).

Impact : d-0003 (`contradiction_sources`) et d-0004 (`donnee_manquante`)
passent de `VERIFY` à `STOP`. 2 tests ajoutés
(`test_broken_confidence_forces_stop_at_any_t`,
`test_known_states_unchanged_by_stop_extension`). Voir
`docs/decisions_a_trancher.md` §2.

SEEK est documenté comme sous-état d'exécution de la métacognition (pas
une sortie de h) : voir `docs/decisions_a_trancher.md` §1.
